package com.reto4.reto4.repositorio.crud;

import com.reto4.reto4.modelo.Computer;

import org.springframework.data.repository.CrudRepository;

public interface ComputerCrudRepositorio extends CrudRepository<Computer,Integer>{
    
}
