package com.reto4.reto4.repositorio.crud;

import com.reto4.reto4.modelo.Client;

import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepositorio extends CrudRepository <Client,Integer>{
    
}
